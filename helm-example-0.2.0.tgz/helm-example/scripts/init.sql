CREATE DATABASE IF NOT EXISTS k8s;
USE k8s;
CREATE TABLE users (
 id int AUTO_INCREMENT  PRIMARY KEY,
 name varchar(255) NOT NULL
);
INSERT INTO users(name) VALUES ("giang");
INSERT INTO users(name) VALUES ("nhu");
